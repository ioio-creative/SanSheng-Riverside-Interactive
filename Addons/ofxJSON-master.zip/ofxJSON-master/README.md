# ofxJSON

A simple [openFrameworks](http://openframeworks.cc/) addon for [jsoncpp](https://github.com/open-source-parsers/jsoncpp).

Developed by
- Jeff Crouse _jefftimesten at gmail dot com_ (http://www.jeffcrouse.info)
- Christopher Baker : http://christopherbaker.net
- Andreas Müller : http://www.nanikawa.com


## To Use

- Use the openFrameworks `projectGenerator` to generate the example files or add the addon for your project.
