#pragma once

#include "ofxKinectForWindows2/Device.h"

#define ofxKFW2 ofxKinectForWindows2