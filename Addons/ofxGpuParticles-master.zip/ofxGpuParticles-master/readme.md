# ofxGpuParticles

This openFrameworks addon simplifies the creation of particle systems running on the GPU written in GLSL.

## Usage

See example.
